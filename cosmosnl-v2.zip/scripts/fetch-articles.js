#!/usr/bin/env node
/**
 * scripts/fetch-articles.js
 *
 * Run: npm run fetch-articles
 *
 * Pulls articles from free RSS feeds, passes them through Claude for
 * a Dutch summary + rewrite, and saves as markdown files in content/articles/.
 *
 * Feeds used (all free, no auth):
 *   - NASA News:       https://www.nasa.gov/rss/dyn/breaking_news.rss
 *   - SpaceFlightNow: https://spaceflightnow.com/feed/
 *   - ESA News:        https://www.esa.int/rssfeed/Our_Activities/Space_Science
 */

const fs      = require('fs')
const path    = require('path')
const Parser  = require('rss-parser')

const ARTICLES_DIR  = path.join(__dirname, '..', 'content', 'articles')
const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY

const FEEDS = [
  {
    url:      'https://www.nasa.gov/rss/dyn/breaking_news.rss',
    source:   'NASA',
    category: 'missies',
  },
  {
    url:      'https://spaceflightnow.com/feed/',
    source:   'SpaceflightNow',
    category: 'missies',
  },
  {
    url:      'https://www.esa.int/rssfeed/Our_Activities/Space_Science',
    source:   'ESA',
    category: 'educatie',
  },
]

const CATEGORY_MAP = {
  'james webb': 'james-webb',
  'webb':       'james-webb',
  'jwst':       'james-webb',
  'mars':       'mars',
  'spacex':     'missies',
  'starship':   'missies',
  'rocket':     'missies',
  'black hole': 'zwarte-gaten',
  'exoplanet':  'exoplaneten',
  'moon':       'maan',
  'comet':      'kometen',
  'dark energy':'kosmologie',
  'galaxy':     'kosmologie',
}

function guessCategory(title, defaultCat) {
  const lower = title.toLowerCase()
  for (const [keyword, cat] of Object.entries(CATEGORY_MAP)) {
    if (lower.includes(keyword)) return cat
  }
  return defaultCat
}

function slugify(str) {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .slice(0, 60)
}

async function translateAndSummarise(title, content) {
  if (!ANTHROPIC_KEY) {
    console.warn('  No ANTHROPIC_API_KEY — skipping AI translation')
    return { titleNL: title, excerptNL: content?.slice(0, 200) || '', bodyNL: content || '' }
  }

  const prompt = `Je bent een redacteur van een Nederlandse astronomie-website. Vertaal en herschrijf het volgende Engelstalige nieuwsartikel in het Nederlands. Geef je antwoord UITSLUITEND als JSON (geen markdown):
{
  "title": "Nederlandse titel",
  "excerpt": "Nederlandse samenvatting in 2-3 zinnen",
  "body": "Volledig artikel in het Nederlands (3-5 alinea's, journalistieke stijl)"
}`

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method:  'POST',
    headers: {
      'Content-Type':      'application/json',
      'x-api-key':         ANTHROPIC_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model:      'claude-sonnet-4-20250514',
      max_tokens: 1000,
      messages:   [{
        role:    'user',
        content: `Titel: ${title}\n\nInhoud: ${content?.slice(0, 1500) || ''}`,
      }],
      system: prompt,
    }),
  })

  const data    = await res.json()
  const rawText = data.content?.[0]?.text || '{}'
  const cleaned = rawText.replace(/```json\n?|\n?```/g, '').trim()

  try {
    const parsed = JSON.parse(cleaned)
    return {
      titleNL:   parsed.title   || title,
      excerptNL: parsed.excerpt || '',
      bodyNL:    parsed.body    || content || '',
    }
  } catch {
    return { titleNL: title, excerptNL: '', bodyNL: content || '' }
  }
}

async function main() {
  if (!fs.existsSync(ARTICLES_DIR)) fs.mkdirSync(ARTICLES_DIR, { recursive: true })

  const parser  = new Parser({ timeout: 10000 })
  let newCount  = 0

  for (const feed of FEEDS) {
    console.log(`\n📡 Fetching: ${feed.source}`)

    let feedData
    try {
      feedData = await parser.parseURL(feed.url)
    } catch (e) {
      console.warn(`  ⚠ Could not fetch ${feed.url}: ${e.message}`)
      continue
    }

    // Take only the 3 most recent items per feed
    const items = feedData.items.slice(0, 3)

    for (const item of items) {
      const title    = item.title?.trim() || 'Untitled'
      const slug     = slugify(title)
      const filePath = path.join(ARTICLES_DIR, `${slug}.md`)

      // Skip if already exists
      if (fs.existsSync(filePath)) {
        console.log(`  ⏭  Already exists: ${title}`)
        continue
      }

      console.log(`  ✍  Processing: ${title}`)

      const content  = item.contentSnippet || item.summary || item.content || ''
      const category = guessCategory(title, feed.category)

      const { titleNL, excerptNL, bodyNL } = await translateAndSummarise(title, content)

      const frontmatter = `---
title: "${titleNL.replace(/"/g, '\\"')}"
excerpt: "${excerptNL.replace(/"/g, '\\"')}"
category: "${category}"
author: "Redactie CosmosNL"
publishedAt: "${new Date().toISOString()}"
featured: false
tags: []
source: "${feed.source}"
sourceUrl: "${item.link || ''}"
---

${bodyNL}
`
      fs.writeFileSync(filePath, frontmatter)
      newCount++
      console.log(`  ✅ Saved: ${slug}.md`)

      // Rate limit: wait 1s between API calls
      await new Promise(r => setTimeout(r, 1000))
    }
  }

  console.log(`\n✨ Done! ${newCount} new articles saved to content/articles/`)
}

main().catch(console.error)
